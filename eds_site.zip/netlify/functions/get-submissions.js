exports.handler = async () => {
  // Simuler quelques données (à remplacer par base de données plus tard)
  const submissions = [
    { nom: "Jean", prenom: "Pierre", whatsapp: "+50912345678" },
    { nom: "Marie", prenom: "Claire", whatsapp: "+50987654321" }
  ];

  return {
    statusCode: 200,
    body: JSON.stringify(submissions)
  };
};